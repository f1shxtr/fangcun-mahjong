"""Python rules run inside Pyodide; native calculations are bridged to WASM."""
import json
import sys
import types
from js import nativeEval

TILES=tuple(f'{s}{n}' for s in 'WTB' for n in range(1,10))+tuple(f'F{n}' for n in range(1,5))+tuple(f'J{n}' for n in range(1,4))
INDEX={t:i for i,t in enumerate(TILES)}

def native(message):
    result=json.loads(nativeEval(message))
    if isinstance(result,dict): raise TypeError(result['error'])
    return result

def fan(pack,hand,winTile,flowerCount,isSelfDrawn,is4thTile,isAboutKong,isWallLast,seatWind,prevalentWind):
    values=['F',len(pack)]
    for kind,tile,offer in pack: values.extend(({'CHI':1,'PENG':2,'GANG':3}[kind],INDEX[tile],offer))
    values.extend((len(hand),*(INDEX[t] for t in hand),INDEX[winTile],flowerCount,
                   int(isSelfDrawn)+2*int(is4thTile)+4*int(isAboutKong)+8*int(isWallLast),seatWind,prevalentWind))
    return tuple(tuple(f) for f in native(' '.join(map(str,values))))

def analyze(counts):
    value,mask=native('S '+' '.join(map(str,counts)))
    return value,tuple(mask)

gb=types.ModuleType('MahjongGB');gb.MahjongFanCalculator=fan;sys.modules['MahjongGB']=gb
shanten=types.ModuleType('mahjong_ai._shanten');shanten.analyze=analyze;sys.modules['mahjong_ai._shanten']=shanten

from mahjong_ai.web.game import Table
table=Table()
save=None

def restore(data):
    global table,save
    if data is None:return
    if not isinstance(data,dict) or data.get('schema')!=1:raise ValueError('存档版本不兼容')
    for key in ('round_before','version_before','seed'):
        if type(data.get(key)) is not int or not 0<=data[key]<2**53:raise ValueError('存档无效')
    scores=data.get('scores_before')
    if not isinstance(scores,list) or len(scores)!=4 or any(type(x)is not int for x in scores) or sum(scores)!=0:raise ValueError('存档分数无效')
    actions=data.get('actions')
    if not isinstance(actions,list) or len(actions)>1500:raise ValueError('存档动作无效')
    candidate=Table();candidate.round_no=data['round_before'];candidate.version=data['version_before'];candidate.scores=scores[:]
    candidate.start(candidate.version,data['seed'])
    for row in actions:
        if not isinstance(row,list) or len(row)!=2:raise ValueError('存档动作无效')
        kind,action_id=row
        if kind=='tick':candidate.tick(candidate.version)
        elif kind=='action':candidate.act(candidate.version,action_id)
        else:raise ValueError('存档动作无效')
    table=candidate;save=data

def dispatch(raw):
    global save
    message=json.loads(raw);path=message['path'];body=message.get('body') or {}
    if path=='/api/state':result=table.state()
    elif path=='/api/hint':result={'hint':table.hint()}
    elif path=='/api/new':
        before={'schema':1,'round_before':table.round_no,'version_before':table.version,'scores_before':table.scores[:],'actions':[]}
        result=table.start(body.get('version'));before['seed']=table.env.random_seed;save=before
    elif path in ('/api/tick','/api/action'):
        previous=table.version
        result=table.tick(body.get('version')) if path.endswith('tick') else table.act(body.get('version'),body.get('id'))
        if table.version!=previous:save['actions'].append(['tick' if path.endswith('tick') else 'action',body.get('id')])
    else:raise ValueError('未知操作')
    return json.dumps({'result':result,'save':save},ensure_ascii=False)
