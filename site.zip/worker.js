/* Game and AI stay in this tab's dedicated worker. No game server requests. */
let pyodide,dispatch,queue=Promise.resolve();
const ready=(async()=>{
  postMessage({status:'正在加载本地规则与人机…'});
  importScripts('./mahjong-native.js','./vendor/pyodide/pyodide.js');
  const native=await createMahjongNative({locateFile:name=>new URL(name,self.location.href).href});
  self.nativeEval=message=>native.ccall('evaluate','string',['string'],[message]);
  pyodide=await loadPyodide({indexURL:new URL('./vendor/pyodide/',self.location.href).href});
  const response=await fetch('./game.zip?v=sl30000-1');if(!response.ok)throw new Error('规则文件下载失败');
  pyodide.unpackArchive(await response.arrayBuffer(),'zip');
  await pyodide.loadPackage('numpy');
  const weights=await fetch('./sl30000.npz');if(!weights.ok)throw new Error('SL30000 模型下载失败');
  pyodide.FS.writeFile('/sl30000.npz',new Uint8Array(await weights.arrayBuffer()));
  const bridge=await fetch('./bridge.py?v=sl30000-1');if(!bridge.ok)throw new Error('规则接口加载失败');
  await pyodide.runPythonAsync(await bridge.text());
  dispatch=pyodide.globals.get('dispatch');
  postMessage({status:'牌桌已就绪'});
})();
// Keep startup failures attached until the first request receives them.
ready.catch(()=>{});
self.onmessage=({data})=>{
  queue=queue.then(async()=>{
    try{
      await ready;
      let warning=null;
      if(data.restore){
        const restore=pyodide.globals.get('restore');
        let value;
        try{value=pyodide.toPy(data.restore);restore(value);}
        catch(error){warning='旧牌局存档无法恢复，已回到新牌桌。';console.warn(error);}
        finally{value?.destroy?.();restore.destroy();}
      }
      const response=JSON.parse(dispatch(JSON.stringify({path:data.path,body:data.body})));
      postMessage({id:data.id,...response,warning});
    }catch(error){console.error(error);postMessage({id:data.id,error:'规则运行失败：'+String(error.message||error)});}
  });
};
