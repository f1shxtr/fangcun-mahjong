/* Four-seat browser speech, driven only by newly accepted public events. */
function createMahjongSpeech(host,onIdle=()=>{}) {
  const synth=host.speechSynthesis, supported=!!(synth&&host.SpeechSynthesisUtterance);
  const profiles=[{pitch:1,rate:1.08},{pitch:1.24,rate:1.15},{pitch:.88,rate:1.02},{pitch:.68,rate:.93}];
  const seats=['东家','南家','西家','北家'];
  let enabled=true,volume=.8,unlocked=false,voices=[],queue=[],current=null,epoch=0,round=null,last=-1,watchdog=null;
  let notify=()=>{};
  try{const saved=JSON.parse(host.localStorage.getItem('mahjong-speech-v1')||'null');if(saved){enabled=saved.enabled!==false;if(Number.isFinite(saved.volume))volume=Math.max(0,Math.min(1,saved.volume));}}catch(_){}
  const persist=()=>{try{host.localStorage.setItem('mahjong-speech-v1',JSON.stringify({enabled,volume}));}catch(_){}};
  const tileName=code=>{if(!code)return '';const n=Number(code[1]);return code[0]==='F'?['东风','南风','西风','北风'][n-1]:code[0]==='J'?['红中','发财','白板'][n-1]:'一二三四五六七八九'[n-1]+({W:'万',T:'条',B:'筒'}[code[0]]||'');};
  function cancel(){epoch++;queue=[];current=null;if(watchdog)host.clearTimeout(watchdog);watchdog=null;if(supported)synth.cancel();onIdle();}
  function refresh(){voices=supported?synth.getVoices().filter(v=>/^zh(?:-|_|$)|^cmn(?:-|_|$)/i.test(v.lang)).sort((a,b)=>Number(!a.localService)-Number(!b.localService)||Number(!/CN|Hans/i.test(a.lang))-Number(!/CN|Hans/i.test(b.lang))||a.name.localeCompare(b.name)):[];notify();}
  function pump(){
    if(current||!queue.length)return;
    if(!enabled||!unlocked||host.document.hidden||!voices.length||volume===0){queue=[];onIdle();return;}
    const item=queue.shift(),token=epoch,u=new host.SpeechSynthesisUtterance(item.text),profile=profiles[item.seat];
    u.voice=voices[item.seat%voices.length];u.lang=u.voice.lang;u.pitch=profile.pitch;u.rate=profile.rate;u.volume=volume;current=u;
    let done=false;const finish=()=>{if(done||token!==epoch)return;done=true;host.clearTimeout(watchdog);watchdog=null;current=null;if(queue.length)pump();else onIdle();};
    u.onend=finish;u.onerror=event=>{if(event.error==='not-allowed'){unlocked=false;notify();}finish();};
    // A broken speech driver must never stall the game indefinitely.
    watchdog=host.setTimeout(()=>{if(token!==epoch)return;synth.cancel();finish();},Math.max(5000,item.text.length*500));
    try{synth.speak(u);}catch(_){finish();}
  }
  function say(seat,text){if(!supported||!enabled||!unlocked||host.document.hidden||volume===0||!voices.length)return;queue.push({seat,text});if(queue.length>8)queue.shift();pump();}
  function observe(state){
    const events=state.events||[],latest=events.at(-1)?.index??-1;
    if(round===null){round=state.round||0;last=latest;return;}
    if(round!==state.round){cancel();round=state.round;last=-1;}
    for(const event of events){
      if(event.index<=last)continue;last=event.index;
      if(!Number.isInteger(event.player)||event.player<0||event.player>3)continue;
      let text='';
      if(event.kind==='PLAY')text=tileName(event.tile);
      else if(event.kind==='CHI')text='吃，打出'+tileName(event.tile);
      else if(event.kind==='PENG')text='碰，打出'+tileName(event.tile);
      else if(['EXPOSED_KONG','CONCEALED_KONG','ADDED_KONG'].includes(event.kind))text=event.kind==='CONCEALED_KONG'?'暗杠':event.kind==='ADDED_KONG'?'补杠':'杠';
      else if(event.kind==='HU'){cancel();text=state.result?.self_draw?'自摸，胡了':'胡了';}
      if(text)say(event.player,seats[event.player]+'，'+text);
    }
  }
  if(supported)synth.addEventListener('voiceschanged',refresh);
  refresh();
  return {observe,cancel,activate(){unlocked=true;refresh();},
    get pending(){return !!current||queue.length>0;},
    get info(){return {supported,enabled,volume,unlocked,voices:voices.length};},
    setListener(fn){notify=fn;notify();},
    setEnabled(value){enabled=!!value;persist();if(!enabled)cancel();notify();},
    setVolume(value){volume=Math.max(0,Math.min(1,Number(value)));persist();if(current)current.volume=volume;if(volume===0)cancel();notify();},
    preview(seat){unlocked=true;refresh();cancel();say(seat,seats[seat]+'，五万，碰，胡了');}
  };
}
if(typeof module!=='undefined'&&module.exports)module.exports={createMahjongSpeech};

/* Original vector tile artwork. All coordinates are in a 60 x 80 face. */
const MahjongTiles = (() => {
  const green='#12613c',blue='#173d75',red='#b52e2b';
  const circle=(x,y,r,color)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="none" stroke="${color}" stroke-width="2.5"/><circle cx="${x}" cy="${y}" r="${r*.55}" fill="none" stroke="${color}" stroke-width="1.5"/><circle cx="${x}" cy="${y}" r="1.4" fill="${color}"/>`;
  const stick=(x,y,color=green,h=18)=>`<g stroke="${color}" stroke-linecap="round"><path d="M${x-2} ${y-h/2}v${h}m4 0v-${h}" stroke-width="2.4"/><path d="M${x-4} ${y-h/2+2}h8m-8 ${h/2-2}h8m-8 ${h/2-2}h8" stroke-width="2"/></g>`;
  const text=(word,x,y,size,color)=>`<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="central" fill="${color}" font-size="${size}" font-weight="700" font-family="KaiTi,STKaiti,SimSun,serif">${word}</text>`;
  function dots(n){
    if(n===1)return circle(30,40,20,blue)+circle(30,40,11,green)+circle(30,40,4,red);
    const points={2:[[30,19],[30,61]],3:[[15,19],[30,40],[45,61]],4:[[16,20],[44,20],[16,60],[44,60]],5:[[15,18],[45,18],[30,40],[15,62],[45,62]],6:[[16,17],[44,17],[16,42],[44,42],[16,65],[44,65]],7:[[12,13],[30,23],[48,33],[16,49],[44,49],[16,68],[44,68]],8:[[16,12],[44,12],[16,30],[44,30],[16,50],[44,50],[16,68],[44,68]],9:[[12,16],[30,16],[48,16],[12,40],[30,40],[48,40],[12,64],[30,64],[48,64]]}[n];
    return points.map(([x,y],i)=>circle(x,y,n>=7?6.5:n>=5?8:10,
      n===2?green:n===3?(i===1?red:blue):n===5?(i===2?red:blue):n===6?(i<2?green:red):n===7?(i<3?green:red):n===9?(i>=3&&i<6?red:blue):blue)).join('');
  }
  function bamboo(n){
    if(n===1)return `<g fill="none" stroke="${green}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M28 26C22 23 21 17 25 14C29 10 35 11 36 16C37 21 33 24 30 26M35 16l8 2-8 3M26 12l-4-4m7 3l-1-5m5 6l3-5"/><circle cx="31" cy="16" r="1" fill="${green}"/><path d="M27 25C20 29 20 40 25 48C29 55 37 52 38 45C39 36 33 33 31 25M24 31Q30 26 34 34Q37 42 30 47Q24 44 25 37Z M27 32q7 4 6 11m-8-6l6 8m-8-3l6 6M25 49l4 12m7-12l3 10M29 61l-5 3m5-3l5 2m5-4l-3 3m3-3l5 1"/><path d="M23 35L13 26L10 24L14 42L24 49M19 34L15 32L18 43M24 46L18 55L22 69L30 58M21 54l4 10M31 51L34 66L40 73L37 56"/><path d="M21 30Q14 27 13 21Q13 17 17 18Q21 21 18 25M23 36Q12 38 9 34Q5 30 9 29Q13 28 15 33M36 31Q42 25 46 29Q49 32 44 34Q40 35 39 31M38 39Q46 36 49 40Q51 44 46 44Q42 44 42 40" stroke-width="1.3"/></g>`;
    if(n===8)return [0,1].map(row=>{const y=row?46:12;const a=row?y+20:y,b=row?y:y+20;return `<g fill="none" stroke="${green}" stroke-linecap="round" stroke-linejoin="round"><path d="M11 ${a}V${b}L30 ${a}L49 ${b}V${a}" stroke-width="5"/><path d="M11 ${a}V${b}L30 ${a}L49 ${b}V${a}" stroke="#e9e2d0" stroke-width="1.5"/><path d="M8 ${y+4}h6m-6 12h6M46 ${y+4}h6m-6 12h6" stroke-width="1.4"/></g>`;}).join('');
    const points={2:[[30,20],[30,60]],3:[[30,18],[17,59],[43,59]],4:[[17,20],[43,20],[17,60],[43,60]],5:[[14,17],[46,17],[30,40],[14,63],[46,63]],6:[[14,20],[30,20],[46,20],[14,60],[30,60],[46,60]],7:[[30,12],[14,38],[30,38],[46,38],[14,64],[30,64],[46,64]],9:[[14,15],[30,15],[46,15],[14,40],[30,40],[46,40],[14,65],[30,65],[46,65]]}[n];
    return points.map(([x,y],i)=>stick(x,y,n===5&&i===2||n===7&&i===0||n===9&&i>=3&&i<6?red:green,n===2?27:18)).join('');
  }
  function markup(code){
    if(code==='T1'||code==='T8'){const asset=code==='T1'?'26-bamboos-1':'33-bamboos-8';return `<svg class="tile-art" viewBox="0 0 60 80" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg"><image href="./tile-assets/${asset}.svg" width="60" height="80" preserveAspectRatio="xMidYMid meet"/></svg>`;}
    const n=Number(code[1]);let art='';
    if(code[0]==='B')art=dots(n);
    else if(code[0]==='T')art=bamboo(n);
    else if(code[0]==='W')art=text('一二三四五六七八九'[n-1],30,22,31,blue)+text('萬',30,57,36,red);
    else if(code==='J3')art=`<rect x="11" y="9" width="38" height="62" rx="2" fill="none" stroke="${blue}" stroke-width="3"/><rect x="16" y="14" width="28" height="52" rx="1" fill="none" stroke="${blue}" stroke-width="1"/>`;
    else art=text(code[0]==='F'?'東南西北'[n-1]:n===1?'中':'發',30,40,49,code[0]==='F'?blue:n===1?red:green);
    return `<svg class="tile-art" viewBox="0 0 60 80" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">${art}</svg>`;
  }
  return {markup};
})();

'use strict';
const $=id=>document.getElementById(id);
const names=['你','岚','竹','松'],winds=['东','南','西','北'];
const rankNames=['','一','二','三','四','五','六','七','八','九'];
const kinds={PASS:'过',HU:'胡',PLAY:'打出',CHI:'吃',PENG:'碰',EXPOSED_KONG:'明杠',CONCEALED_KONG:'暗杠',ADDED_KONG:'补杠'};
let state={version:0,started:false,totals:[0,0,0,0]},busy=false,paused=false,timer=null,selected=null,group=null,lastDialogRound=0;
let speechInitialized=false,autoplay=false,autoEpoch=0;
const speech=createMahjongSpeech(window,()=>schedule());
function tileName(code){if(!code)return '暗牌';const n=Number(code.slice(1));return code[0]==='F'?winds[n-1]:code[0]==='J'?['中','發','白'][n-1]:rankNames[n]+({W:'万',T:'条',B:'筒'}[code[0]]||'');}
function tile(code,button=false){
  const e=document.createElement(button?'button':'span');e.className='tile';e.dataset.tile=code||'';
  if(!code){e.className='back';e.setAttribute('aria-label','暗牌');return e;}
  e.innerHTML=MahjongTiles.markup(code);
  e.setAttribute('aria-label',tileName(code));e.title=tileName(code);return e;
}
function toast(message,error=false){$('toast').textContent=message;$('toast').classList.toggle('error',error);$('toast').hidden=false;clearTimeout(toast.timeout);toast.timeout=setTimeout(()=>$('toast').hidden=true,4500);}
async function request(path,body){return BrowserEngine.request(path,body); }
function canAdvance(){return state.started&&!state.done&&!paused&&!document.hidden&&!$('rules').open&&!$('settlement').open;}
function schedule(){clearTimeout(timer);if(canAdvance()&&(!state.needs_input||autoplay)&&!busy&&!speech.pending)timer=setTimeout(()=>send(state.needs_input?'/api/auto':'/api/tick'),Number($('speed').value));}
function setAutoplay(value){autoEpoch++;autoplay=!!value;selected=null;group=null;render();schedule();}

async function send(path,extra={}){
  if(busy)return;clearTimeout(timer);busy=true;renderHand();renderActions();
  try{
    if(path==='/api/auto'){
      const epoch=autoEpoch,version=state.version;
      if(!autoplay||!canAdvance()||!state.needs_input)return;
      const {hint}=await request('/api/hint');
      // Taking control, pausing or opening a guide cancels an unsubmitted AI choice.
      if(epoch!==autoEpoch||!autoplay||!canAdvance()||version!==state.version)return;
      if(!hint||hint.version!==version||!state.actions.some(a=>a.id===hint.id))throw new Error('托管建议已失效，请重新开启托管。');
      path='/api/action';extra={id:hint.id};
    }
    state=await request(path,{version:state.version,...extra});selected=null;group=null;render();speech.observe(state);}
  catch(e){toast(e.message,true);paused=true;try{state=await request('/api/state');render();}catch(_){$('turn-title').textContent='连接已断开';$('turn-detail').textContent='请刷新页面恢复牌局。';}}
  finally{busy=false;render();schedule();}
}
function meldView(m){const wrap=document.createElement('div');wrap.className='meld';for(const t of m.tiles)wrap.append(tile(t));if(m.concealed){const label=document.createElement('span');label.className='meld-label';label.textContent='暗';wrap.append(label);}return wrap;}
function renderOpponents(){for(const seat of [1,2,3]){const root=$('player-'+seat),p=state.players?.[seat]||{name:names[seat],wind:winds[seat],count:13,melds:[]};root.replaceChildren();root.classList.toggle('active-seat',state.started&&!state.done&&state.active_player===seat);const identity=document.createElement('div');identity.className='player-identity';identity.innerHTML=`<span class="avatar">${winds[seat]}</span><div><div class="player-name">${names[seat]} · ${['','下家','对家','上家'][seat]}</div><div class="player-sub">${state.agent_name||"SL30000 人机"}</div></div>`;root.append(identity);const backs=document.createElement('div');backs.className='backs';backs.setAttribute('aria-label',`暗手 ${p.count} 张`);for(let i=0;i<p.count;i++)backs.append(tile(null));root.append(backs);const melds=document.createElement('div');melds.className='melds';for(const m of p.melds)melds.append(meldView(m));root.append(melds);}}
function renderRivers(){const root=$('rivers');root.replaceChildren();const latest=state.events?.at(-1)?.index;for(const seat of [3,2,0,1]){const river=document.createElement('div');river.className='river';const label=document.createElement('span');label.className='river-label';label.textContent=(seat===0?'你':names[seat])+'的牌河';river.append(label);for(const item of state.rivers?.[seat]||[]){const e=tile(item.tile);if(item.claimed){e.classList.add('claimed');e.title+=' · 已被吃碰杠';}if(item.event===latest)e.classList.add('recent');river.append(e);}root.append(river);}}
function actionText(a){if(a.type==='PLAY')return '打出 '+tileName(a.discard_tile);if(a.type==='CHI'||a.type==='PENG')return `${kinds[a.type]} ${a.meld.map(tileName).join(' ')}，打 ${tileName(a.discard_tile)}`;if(a.type==='PASS')return '过';if(a.type==='HU')return '胡牌';return kinds[a.type]+' '+tileName(a.meld[0]);}
function eventText(e){const who=e.player===null?'本局':names[e.player];if(e.kind==='START')return `${who}先摸，牌局开始`;if(e.kind==='DRAW_GAME')return '牌墙已尽，本局流局';if(e.kind==='DRAW')return who+(e.player===0?'摸到 '+tileName(e.tile):'摸了一张牌');if(e.kind==='PLAY')return who+'打出 '+tileName(e.tile);if(e.kind==='CHI'||e.kind==='PENG')return `${who}${kinds[e.kind]} ${e.meld.map(tileName).join(' ')}，打出 ${tileName(e.tile)}`;if(e.kind==='HU')return who+'胡牌 · '+tileName(e.tile);return who+(kinds[e.kind]||e.kind)+(e.tile?' '+tileName(e.tile):'');}
function matchingDiscards(){return (state.actions||[]).filter(a=>group?group.actions.some(g=>g.id===a.id):a.type==='PLAY');}
function selectTile(code){if(busy||autoplay||!state.needs_input)return;if(!matchingDiscards().some(a=>a.discard_tile===code))return;selected=code;renderHand();renderActions();}
function submitDiscard(){if(busy||autoplay)return;const a=matchingDiscards().find(a=>a.discard_tile===selected);if(a)send('/api/action',{id:a.id});}
// The engine accepts claim + discard atomically. Keep a reversible visual draft
// until a legal discard is selected; never mutate the authoritative state.
function displayedHand(){
  const hand=state.started?[...(state.hand||[])]:['W1','W2','W3','T4','T5','T6','B7','B8','B9','F1','F1','J2','J2'];
  if(state.drawn)hand.push(state.drawn);
  if(group){
    const a=group.actions[0],used=[...a.meld];
    used.splice(used.indexOf(a.claimed_tile),1);
    for(const code of used){const i=hand.indexOf(code);if(i>=0)hand.splice(i,1);}
  }
  return hand;
}
function chooseMeld(g){if(busy||autoplay)return;autoEpoch++;group=g;selected=null;render();}
function renderHand(){
  const root=$('hand'),melds=$('own-melds');root.replaceChildren();melds.replaceChildren();
  for(const m of state.players?.[0]?.melds||[])melds.append(meldView(m));
  if(group){
    const m=meldView({tiles:group.actions[0].meld});m.classList.add('pending-meld');
    m.setAttribute('aria-label',group.label+'，待打出一张牌');
    const label=document.createElement('span');label.className='meld-label';label.textContent=kinds[group.actions[0].type]+' · 待出牌';m.append(label);melds.append(m);
  }
  const hand=displayedHand(),valid=matchingDiscards().map(a=>a.discard_tile);
  hand.forEach((code,index)=>{
    const e=tile(code,true);if(state.drawn&&!group&&index===hand.length-1)e.classList.add('drawn');
    e.disabled=!(state.needs_input&&!state.done&&!busy&&!autoplay&&valid.includes(code));
    if(!state.needs_input)e.classList.add('idle');e.classList.toggle('selected',selected===code);
    e.setAttribute('aria-pressed',String(selected===code));e.addEventListener('click',()=>selectTile(code));
    e.addEventListener('dblclick',()=>{selectTile(code);submitDiscard();});root.append(e);
  });
  $('meld-preview').hidden=!group;
  if(group){
    $('meld-preview').replaceChildren();const text=document.createElement('strong');text.textContent='② 选择一张手牌打出';
    const cancel=button('重新选择','secondary',()=>{group=null;selected=null;autoEpoch++;render();});
    $('meld-preview').append(text,cancel);
  }
}
function claimButton(a,fn){
  const b=button('','claim-action claim-'+a.type.toLowerCase(),fn);
  b.setAttribute('aria-label',kinds[a.type]+' '+a.meld.map(tileName).join(' '));
  const title=document.createElement('strong');title.textContent=kinds[a.type];
  const faces=document.createElement('span');faces.className='claim-faces';
  let marked=false;
  for(const code of a.meld){const face=tile(code);if(!marked&&code===a.claimed_tile){face.classList.add('claimed-face');marked=true;}faces.append(face);}
  const caption=document.createElement('small');caption.textContent=['CHI','PENG'].includes(a.type)?'① 副露 → ② 出牌':'确认开杠';
  b.append(title,faces,caption);return b;
}

function groups(){const list=[];for(const a of state.actions||[]){if(!['CHI','PENG'].includes(a.type))continue;const key=a.type+':'+a.meld.join(',');let g=list.find(g=>g.key===key);if(!g){g={key,label:kinds[a.type]+' '+(a.type==='CHI'?a.meld.map(tileName).join(' '):tileName(a.claimed_tile)),actions:[]};list.push(g);}g.actions.push(a);}return list;}
function button(text,cls,fn){const e=document.createElement('button');e.textContent=text;e.className=cls;e.disabled=busy;e.onclick=fn;return e;}
function renderActions(){const bar=$('actions');bar.replaceChildren();if(state.done){bar.append(button('查看结算','secondary',()=>showResult(true)));return;}if(!state.started)return;if(autoplay){bar.append(button('接管 · 自己打','secondary',()=>setAutoplay(false)));bar.lastChild.disabled=false;return;}if(!state.needs_input){bar.append(button(paused?'继续人机':'人机行动中…','secondary',()=>{paused=false;render();schedule();}));if(!paused)bar.lastChild.disabled=true;return;}
  if(group||state.actions.some(a=>a.type==='PLAY')){const b=button(selected?'打出 '+tileName(selected):'选择要打的牌','primary',submitDiscard);b.disabled=busy||!selected;bar.append(b);}
  if(!group){for(const g of groups())bar.append(claimButton(g.actions[0],()=>chooseMeld(g)));for(const a of state.actions){if(['PLAY','CHI','PENG'].includes(a.type))continue;const text=a.type==='PASS'?'过':a.type==='HU'?'胡牌':kinds[a.type]+' '+tileName(a.meld[0]);bar.append(a.type.includes('KONG')?claimButton(a,()=>send('/api/action',{id:a.id})):button(text,a.type==='HU'?'primary hu-button claim-hu':'secondary pass-action',()=>send('/api/action',{id:a.id})));}}
}
function render(){
  if(!speechInitialized){speech.observe(state);speechInitialized=true;}
  $('welcome').hidden=state.started;$('round-label').textContent=state.started?`第 ${state.round} 局 · ${state.round_wind}风圈`:'国标 · 无花牌';$('wind-label').textContent=(state.round_wind||'东')+'风圈';$('wall-count').textContent=state.started?state.wall_count:'84';
  $('pause').disabled=!state.started||state.done;$('pause').textContent=paused?'继续人机':'暂停人机';$('new-round').disabled=!state.started;$('hint').disabled=!state.needs_input||state.done||busy||autoplay||!!group;
  $('autoplay').textContent=autoplay?'接管 · 自己打':'托管 · 看 AI 打';$('autoplay').setAttribute('aria-pressed',String(autoplay));
  $('autoplay-status').textContent=autoplay?(state.done?'本局已结束，下一局继续托管。':paused?'托管已暂停，点击「继续人机」恢复。':!state.started?'开局后，四家将自动对战。':'托管中：AI 代你出牌、吃碰杠胡，可随时接管。'):'开启后由所选人机策略代你决策；本局结束后停在结算。';
  const turn=state.done?'本局结束':!state.started?'准备入座':paused?'人机已暂停':autoplay&&state.needs_input?'托管 AI 正在决策':group?'副露已摆好，请出牌':state.needs_input?(state.actions.some(a=>a.type==='PLAY')?'轮到你出牌':'你可以响应这张牌'):paused?'人机已暂停':names[state.active_player]+'正在行动';
  $('turn-title').textContent=turn;$('turn-dot').classList.toggle('yours',!!state.needs_input&&!state.done);
  const latest=state.events?.at(-1);$('turn-detail').textContent=state.done?'可以查看番种和各家手牌。':latest?eventText(latest):'你坐东位，先来一局试试。';
  $('hand-help').textContent=autoplay?'正在托管，可点击「接管 · 自己打」恢复手动操作。':group?'从剩余手牌中选一张打出。':state.needs_input?'点选手牌，再点「打出」；双击可出牌。':'无需操作时，牌局会自动继续。';
  renderOpponents();renderRivers();renderHand();renderActions();
  const response=state.needs_input&&!state.done&&!autoplay&&!group&&(state.actions||[]).some(a=>['CHI','PENG','HU','EXPOSED_KONG'].includes(a.type));
  document.querySelector('.hand-panel').classList.toggle('response-needed',response);
  $('claim-notice').hidden=!response;$('claim-notice').replaceChildren();
  if(response){const a=state.actions.find(a=>a.claimed_tile);const label=document.createElement('strong');label.textContent=a?'有人打出 '+tileName(a.claimed_tile)+' · 请选择':'可以胡牌 · 请选择';$('claim-notice').append(label);if(a)$('claim-notice').append(tile(a.claimed_tile));}

  const agentName=state.agent_name||'牌效率人机';
  document.querySelectorAll('.player-sub').forEach(el=>el.textContent=agentName);
  $('hint').textContent='✧ 人机建议';
  if(!autoplay)$('autoplay-status').textContent=`开启后由${agentName}代你决策；本局结束后停在结算。`;
  $('scoreboard').replaceChildren();for(let i=0;i<4;i++){const row=document.createElement('div');row.className='score-row'+(i===0?' you':'');const score=state.totals?.[i]||0;row.innerHTML=`<span class="score-name"><span class="score-wind">${winds[i]}</span>${i===0?'你':names[i]+' · 人机'}</span><strong>${score>0?'+':''}${score}</strong>`;$('scoreboard').append(row);}
  if(state.events){$('history').replaceChildren();for(const e of [...state.events].reverse().slice(0,24)){const li=document.createElement('li'),dot=document.createElement('span'),text=document.createElement('span');dot.className='event-dot';dot.textContent='·';text.textContent=eventText(e);li.append(dot,text);$('history').append(li);}$('event-count').textContent=state.done?'已结算':'最近 24 步';}
  if(state.done&&lastDialogRound!==state.round){lastDialogRound=state.round;showResult();}
}
function showResult(force=false){if(!state.result)return;const r=state.result,root=$('result-content');root.replaceChildren();const eyebrow=document.createElement('span');eyebrow.className='eyebrow';eyebrow.textContent='ROUND COMPLETE';const title=document.createElement('h2');title.textContent=r.winner===null?'牌墙尽了，下一局见。':(r.winner===0?'你':names[r.winner])+(r.self_draw?'自摸':'胡牌')+` · ${r.fan_total} 番`;root.append(eyebrow,title);const scores=document.createElement('div');scores.className='result-scores';r.scores.forEach((s,i)=>{const card=document.createElement('div');card.className='result-score';card.innerHTML=`${names[i]}<strong class="${s>0?'positive':s<0?'negative':''}">${s>0?'+':''}${s}</strong>`;scores.append(card);});root.append(scores);const fans=document.createElement('div');fans.className='fan-list';for(const f of r.fans){const item=document.createElement('span');item.textContent=`${f.name}${f.count>1?' ×'+f.count:''} · ${f.points} 番`;fans.append(item);}root.append(fans);r.hands.forEach((hand,seat)=>{const row=document.createElement('div');row.className='reveal-row';const label=document.createElement('span');label.textContent=names[seat]+'的手牌'+(seat===r.winner?' · 已含和牌张':'');const tiles=document.createElement('div');tiles.className='reveal-hand';hand.forEach(t=>tiles.append(tile(t)));row.append(label,tiles);const melds=document.createElement('div');melds.className='reveal-melds';for(const m of state.players[seat].melds)melds.append(meldView(m));row.append(melds);root.append(row);});if(!$('settlement').open)$('settlement').showModal();}
async function newRound(){if(busy)return;autoEpoch++;clearTimeout(timer);if(state.started&&!state.done&&!confirm('这局还没有结束。重新开局将放弃当前牌局，是否继续？')){schedule();return;}if($('settlement').open)$('settlement').close();speech.cancel();paused=false;await send('/api/new');}
$('start').onclick=newRound;$('new-round').onclick=newRound;$('next-round').onclick=newRound;
$('autoplay').onclick=()=>setAutoplay(!autoplay);
$('pause').onclick=()=>{autoEpoch++;paused=!paused;if(paused)speech.cancel();render();schedule();};$('speed').onchange=schedule;
$('rules-open').onclick=()=>{autoEpoch++;clearTimeout(timer);$('rules').showModal();speech.cancel();};$('rules').addEventListener('close',schedule);document.querySelectorAll('[data-close]').forEach(e=>e.onclick=()=>$(e.dataset.close).close());
$('hint').onclick=async()=>{if(busy||autoplay||group)return;const epoch=autoEpoch;try{const {hint}=await request('/api/hint');if(autoplay||epoch!==autoEpoch||!hint||hint.version!==state.version)return;toast('AI 建议：'+actionText(hint));if(hint.type==='PLAY'){group=null;selected=hint.discard_tile;}else if(['CHI','PENG'].includes(hint.type)){group=groups().find(g=>g.actions.some(a=>a.id===hint.id));selected=hint.discard_tile;}render();}catch(e){toast(e.message,true);}};
document.addEventListener('visibilitychange',()=>{autoEpoch++;schedule();});window.addEventListener('keydown',e=>{if(e.key==='Enter'&&selected&&!document.querySelector('dialog[open]')){e.preventDefault();submitDiscard();}});
(async()=>{try{state=await request('/api/state');render();$('start').disabled=false;$('start').innerHTML='开始第一局 <span>↗</span>';schedule();}catch(e){render();$('engine-status').textContent='加载失败。请检查网络后刷新重试。';toast(e.message,true);}})();

function filterFanGuide(){
  const query=$('fan-search').value.trim().replaceAll('嵌张','坎张');
  const points=$('fan-points').value;let count=0;
  document.querySelectorAll('[data-fan]').forEach(row=>{const match=row.dataset.fan.includes(query)&&(!points||row.dataset.points===points);row.hidden=!match;if(match)count++;});
  $('fan-count').textContent=`显示 ${count} / 81 种`;$('fan-empty').hidden=count!==0;
}
$('fan-search').addEventListener('input',filterFanGuide);$('fan-points').addEventListener('change',filterFanGuide);

document.addEventListener('pointerdown',()=>speech.activate(),{capture:true});
document.addEventListener('keydown',()=>speech.activate(),{capture:true});
document.addEventListener('visibilitychange',()=>{if(document.hidden)speech.cancel();});
window.addEventListener('pagehide',()=>speech.cancel());
speech.setListener(()=>{
  const info=speech.info;
  $('speech-toggle').textContent=info.enabled?'语音：开':'语音：关';
  $('speech-toggle').setAttribute('aria-pressed',String(info.enabled));
  $('speech-toggle').disabled=!info.supported;
  $('speech-volume').value=String(Math.round(info.volume*100));
  $('speech-volume').disabled=!info.supported;
  $('speech-status').textContent=!info.supported?'当前浏览器不支持语音播报。':!info.voices?'尚未检测到中文语音，可换用 Edge / Chrome 或安装系统中文语音。':!info.enabled?'语音已关闭。':!info.unlocked?'点击牌桌或试听后启用播报。':info.voices<4?'已启用：用不同音调、语速区分四家，并报出方位。':'已启用：四家使用不同中文音色，并报出方位。';
  document.querySelectorAll('[data-voice-seat]').forEach(button=>button.disabled=!info.supported||!info.voices||!info.enabled);
});
$('speech-toggle').onclick=()=>{speech.activate();speech.setEnabled(!speech.info.enabled);};
$('speech-volume').oninput=event=>speech.setVolume(Number(event.target.value)/100);
document.querySelectorAll('[data-voice-seat]').forEach(button=>button.onclick=()=>speech.preview(Number(button.dataset.voiceSeat)));

// Reuse the table tile artwork in the illustrated fan reference.
document.querySelectorAll("[data-guide-tile]").forEach(node=>node.replaceWith(tile(node.dataset.guideTile)));

$('agent-mode').addEventListener('change',async()=>{try{state=await request('/api/agent',{mode:$('agent-mode').value});render();}catch(e){toast(e.message,true);$('agent-mode').value=state.agent_mode||'sl30000';}});
const renderBeforeAgentMode=render;
render=function(){renderBeforeAgentMode();$('agent-mode').value=state.agent_mode||'sl30000';$('agent-mode').disabled=Boolean(state.started&&!state.done);};
