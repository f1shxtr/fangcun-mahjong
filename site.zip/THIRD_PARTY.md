# Third-party software

The original tile SVG drawings are MIT-licensed project artwork. No external images or fonts are requested.

- Game environment: ccr-cheng/botzone-mahjong-environment, MIT, original copyright notice in LICENSE.txt. Source: https://github.com/ccr-cheng/botzone-mahjong-environment . Shared Python game sources are included in game.zip.
- Mahjong calculation library: Chinese Official Mahjong Helper by Jeff Wang, MIT. Native source and its original notice are included in native-source.zip. Source: https://github.com/summerinsects/ChineseOfficialMahjongHelper . The shanten cache overflow fix from the local project is retained.
- Pyodide 0.27.7: unmodified upstream distribution files, Mozilla Public License 2.0, included at vendor/pyodide/LICENSE. Corresponding source: https://github.com/pyodide/pyodide/tree/0.27.7 . The interpreter contains CPython 3.12.7 and associated components; upstream source and license notices: https://github.com/python/cpython/blob/v3.12.7/LICENSE . Pyodide build recipes and third-party source/license information: https://github.com/pyodide/pyodide/tree/0.27.7/cpython . No optional Python packages are downloaded by this game.

Build tool (not required by players): Emscripten 4.0.15, https://github.com/emscripten-core/emscripten/tree/4.0.15 . The exported WebAssembly module is separate from Pyodide; calls use a small string-based adapter.

Traditional Hong Kong tile artwork: samoheen/mahjong-tiles, CC0/Public Domain.
Source: https://github.com/samoheen/mahjong-tiles
License: https://github.com/samoheen/mahjong-tiles/blob/master/LICENSE.md
Files used unmodified: hongkong/svg/26-bamboos-1.svg and 33-bamboos-8.svg.
