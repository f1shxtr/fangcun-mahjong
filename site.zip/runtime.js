'use strict';
window.BrowserEngine=(()=>{
  const worker=new Worker(new URL('./worker.js',document.baseURI));
  const pending=new Map();let serial=0,first=true,failed=false;
  const key='fangcun-mahjong-browser-v1';
  worker.onmessage=({data})=>{
    if(data.status){const status=document.getElementById('engine-status');if(status)status.textContent=data.status;return;}
    const waiter=pending.get(data.id);if(!waiter)return;pending.delete(data.id);clearTimeout(waiter.timeout);
    if(data.error){waiter.reject(new Error(data.error));return;}
    try{if(data.save)sessionStorage.setItem(key,JSON.stringify(data.save));else sessionStorage.removeItem(key);}catch(_){/* storage may be disabled; current hand remains playable */}
    if(data.warning)setTimeout(()=>alert(data.warning),0);
    waiter.resolve(data.result);
  };
  worker.onerror=()=>{failed=true;for(const waiter of pending.values()){clearTimeout(waiter.timeout);waiter.reject(new Error('浏览器规则加载失败，请刷新重试。'));}pending.clear();};
  return {request(path,body){
    if(failed)return Promise.reject(new Error('规则已停止，请刷新恢复牌局。'));
    const id=++serial;let restore=null;
    if(first){first=false;try{restore=JSON.parse(sessionStorage.getItem(key)||'null');}catch(_){}}
    return new Promise((resolve,reject)=>{
      const timeout=setTimeout(()=>{failed=true;worker.terminate();for(const entry of pending.values()){clearTimeout(entry.timeout);entry.reject(new Error('加载或计算超时，请刷新重试。'));}pending.clear();},180000);
      pending.set(id,{resolve,reject,timeout});worker.postMessage({id,path,body,restore});
    });
  }};
})();
