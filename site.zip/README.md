# 方寸麻将：纯浏览器单机版

传统麻将牌面：万子中文字、筒子圆点、条子竹节、幺鸡和字牌。未加入翻转示例。

你与三个启发式人机对战。算番、合法动作、对局推进、人机策略全部在各自浏览器的 Web Worker 中运行，没有游戏后端、账号、联机房间或 PPO 模型。完整玩法说明和 81 种番表仍可查阅。

## 本机预览

项目目录 `D:\mahjong-ai\botzone-mahjong-environment`：

```powershell
.\.venv\Scripts\python.exe -B -m http.server 8767 --bind 127.0.0.1 --directory docs
```

打开 http://127.0.0.1:8767/ 。这里 Python 只提供静态文件，不执行游戏逻辑。可用任意静态服务器替代。不能用 `file://` 双击 HTML 启动，因为浏览器 Worker 和 WASM 加载需要 HTTP(S)。

首次打开需加载约 14 MB 未压缩资源；加载完成后，对局计算不再访问游戏服务器。所有运行资源随网站分发，不依赖第三方 CDN。支持当前桌面/手机浏览器的 WebAssembly 与 Web Worker；尚未逐一实测所有浏览器。

当前标签页自动保存种子和动作记录，刷新后重放恢复；关闭标签页可能清空。存储被禁用时仍可玩，但不能保证刷新恢复。不同标签页独立运行。保留原项目无花牌、分家牌墙规则及连续单局练习方式。

## 发布到 GitHub Pages

`docs/` 已是构建好的静态站点。只发布这个目录即可，不需要上传 `.venv`、训练牌谱、模型或报告。

两种摆放方式任选其一：

1. 把 `docs/` 内容放入专用网站仓库根目录：在 GitHub 仓库 Settings → Pages → Deploy from a branch，选择发布分支与 `/(root)`。
2. 把完整 `docs/` 文件夹放入仓库：同一设置选择发布分支与 `/docs`。

保留 `.nojekyll`、`vendor/`、所有 `.wasm`、`game.zip` 和许可证文件。无需 GitHub Actions 编译。根目录与仓库子路径部署都使用相对资源地址。

等 Pages 构建完成后，使用设置页显示的 HTTPS 地址分享。当前尚未发布到公共地址，需要确定你的目标 GitHub 仓库并有相应权限。

官方说明：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## 代码与构建

- `mahjong_ai/web/static/`：共享页面及传统矢量牌面（app.js 含牌面代码，tiles.js 为独立牌面源文件）。
- `browser/bridge.py`：Python 与原生 WASM 接口、存档重放。
- `browser/worker.js`：加载 Pyodide 和现有游戏代码，串行处理回合。
- `browser/runtime.js`：页面与 Worker 通信、当前标签页自动存档。
- `mahjong_ai/native/browser_wrapper.cpp`：算番和五种和牌形式的向听计算接口。
- `docs/`：可直接部署的完整产物，含资源 SHA-256 清单。

构建时使用 Python、Emscripten 4.0.15；玩家不需要安装它们。

```powershell
python tools/fetch_browser_runtime.py
python tools/build_browser.py --runtime-cache .browser-cache/pyodide --emcc PATH/TO/emsdk/upstream/emscripten/em++.py
```

如果原生模块没有变动，已有 `docs/mahjong-native.js` 和 `.wasm` 时可省略 `--emcc`。运行时锁定 Pyodide 0.27.7，下载脚本校验哈希。

## 验证结果

- 500 组原生计算样例与桌面版一致。
- 8 局完整对战、836 步：每一步公开状态、人机建议、合法动作及最终得分一致。
- 存档重放及过期动作拒绝检查通过。
- 实际浏览器验证：在 `/docs/` 子路径加载、开局、出牌、提示、自动人机回合、刷新恢复同一手牌。
- 390px 窄屏检查，14 张牌可完整显示。
- 仅静态资源 GET 请求，无 `/api` 游戏网络请求。

快速复查：

```powershell
python tools/browser_fixtures.py . reports/browser-fixtures.json
node tools/check_browser.cjs docs reports/browser-fixtures.json
```
