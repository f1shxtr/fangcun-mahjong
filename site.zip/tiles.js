/* Original vector tile artwork. All coordinates are in a 60 x 80 face. */
const MahjongTiles = (() => {
  const green='#12613c',blue='#173d75',red='#b52e2b';
  const circle=(x,y,r,color)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="none" stroke="${color}" stroke-width="2.5"/><circle cx="${x}" cy="${y}" r="${r*.55}" fill="none" stroke="${color}" stroke-width="1.5"/><circle cx="${x}" cy="${y}" r="1.4" fill="${color}"/>`;
  const stick=(x,y,color=green,h=18)=>`<g stroke="${color}" stroke-linecap="round"><path d="M${x-2} ${y-h/2}v${h}m4 0v-${h}" stroke-width="2.4"/><path d="M${x-4} ${y-h/2+2}h8m-8 ${h/2-2}h8m-8 ${h/2-2}h8" stroke-width="2"/></g>`;
  const text=(word,x,y,size,color)=>`<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="central" fill="${color}" font-size="${size}" font-weight="700" font-family="KaiTi,STKaiti,SimSun,serif">${word}</text>`;
  function dots(n){
    if(n===1)return circle(30,40,20,blue)+circle(30,40,11,green)+circle(30,40,4,red);
    const points={2:[[30,19],[30,61]],3:[[15,19],[30,40],[45,61]],4:[[16,20],[44,20],[16,60],[44,60]],5:[[15,18],[45,18],[30,40],[15,62],[45,62]],6:[[16,17],[44,17],[16,42],[44,42],[16,65],[44,65]],7:[[12,13],[30,23],[48,33],[16,49],[44,49],[16,68],[44,68]],8:[[16,12],[44,12],[16,30],[44,30],[16,50],[44,50],[16,68],[44,68]],9:[[12,16],[30,16],[48,16],[12,40],[30,40],[48,40],[12,64],[30,64],[48,64]]}[n];
    return points.map(([x,y],i)=>circle(x,y,n>=7?6.5:n>=5?8:10,
      n===2?green:n===3?(i===1?red:blue):n===5?(i===2?red:blue):n===6?(i<2?green:red):n===7?(i<3?green:red):n===9?(i>=3&&i<6?red:blue):blue)).join('');
  }
  function bamboo(n){
    if(n===1)return `<g stroke-linecap="round" stroke-linejoin="round"><path d="M28 38C8 47 12 64 25 66C42 66 49 50 39 38C35 32 29 34 31 24C32 17 40 16 42 23" fill="${green}"/><path d="M26 44Q14 58 27 61Q38 58 39 44Q31 51 26 44" fill="#f4efdb"/><path d="M27 46l-5 10m10-12l-5 13m9-12l-5 13M20 64L12 75m16-10l-2 10m7-13l7 12" fill="none" stroke="${blue}" stroke-width="3"/><circle cx="36" cy="23" r="7" fill="${green}"/><circle cx="38" cy="21" r="1.4" fill="#fff"/><path d="M42 23l10 4-10 2M32 16l-1-7 6 7" fill="${red}"/><path d="M23 35q-8-5-10-14m16 12q-7-10-5-17" fill="none" stroke="${red}" stroke-width="2"/></g>`;
    if(n===8)return [[18,20,-24],[42,20,24],[18,60,24],[42,60,-24]].map(([x,y,a])=>`<g transform="rotate(${a} ${x} ${y})">${stick(x-4,y,green,22)}${stick(x+4,y,green,22)}</g>`).join('');
    const points={2:[[30,20],[30,60]],3:[[30,18],[17,59],[43,59]],4:[[17,20],[43,20],[17,60],[43,60]],5:[[14,17],[46,17],[30,40],[14,63],[46,63]],6:[[14,20],[30,20],[46,20],[14,60],[30,60],[46,60]],7:[[30,12],[14,38],[30,38],[46,38],[14,64],[30,64],[46,64]],9:[[14,15],[30,15],[46,15],[14,40],[30,40],[46,40],[14,65],[30,65],[46,65]]}[n];
    return points.map(([x,y],i)=>stick(x,y,n===5&&i===2||n===7&&i===0||n===9&&i>=3&&i<6?red:green,n===2?27:18)).join('');
  }
  function markup(code){
    const n=Number(code[1]);let art='';
    if(code[0]==='B')art=dots(n);
    else if(code[0]==='T')art=bamboo(n);
    else if(code[0]==='W')art=text('一二三四五六七八九'[n-1],30,22,31,blue)+text('萬',30,57,36,red);
    else if(code==='J3')art=`<rect x="11" y="9" width="38" height="62" rx="2" fill="none" stroke="${blue}" stroke-width="3"/><rect x="16" y="14" width="28" height="52" rx="1" fill="none" stroke="${blue}" stroke-width="1"/>`;
    else art=text(code[0]==='F'?'東南西北'[n-1]:n===1?'中':'發',30,40,49,code[0]==='F'?blue:n===1?red:green);
    return `<svg class="tile-art" viewBox="0 0 60 80" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">${art}</svg>`;
  }
  return {markup};
})();
