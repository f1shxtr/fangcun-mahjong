/* Original vector tile artwork. All coordinates are in a 60 x 80 face. */
const MahjongTiles = (() => {
  const green='#12613c',blue='#173d75',red='#b52e2b';
  const circle=(x,y,r,color)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="none" stroke="${color}" stroke-width="2.5"/><circle cx="${x}" cy="${y}" r="${r*.55}" fill="none" stroke="${color}" stroke-width="1.5"/><circle cx="${x}" cy="${y}" r="1.4" fill="${color}"/>`;
  const stick=(x,y,color=green,h=18)=>`<g stroke="${color}" stroke-linecap="round"><path d="M${x-2} ${y-h/2}v${h}m4 0v-${h}" stroke-width="2.4"/><path d="M${x-4} ${y-h/2+2}h8m-8 ${h/2-2}h8m-8 ${h/2-2}h8" stroke-width="2"/></g>`;
  const text=(word,x,y,size,color)=>`<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="central" fill="${color}" font-size="${size}" font-weight="700" font-family="KaiTi,STKaiti,SimSun,serif">${word}</text>`;
  function dots(n){
    if(n===1)return circle(30,40,20,blue)+circle(30,40,11,green)+circle(30,40,4,red);
    const points={2:[[30,19],[30,61]],3:[[15,19],[30,40],[45,61]],4:[[16,20],[44,20],[16,60],[44,60]],5:[[15,18],[45,18],[30,40],[15,62],[45,62]],6:[[16,17],[44,17],[16,42],[44,42],[16,65],[44,65]],7:[[12,13],[30,23],[48,33],[16,49],[44,49],[16,68],[44,68]],8:[[16,12],[44,12],[16,30],[44,30],[16,50],[44,50],[16,68],[44,68]],9:[[12,16],[30,16],[48,16],[12,40],[30,40],[48,40],[12,64],[30,64],[48,64]]}[n];
    return points.map(([x,y],i)=>circle(x,y,n>=7?6.5:n>=5?8:10,
      n===2?green:n===3?(i===1?red:blue):n===5?(i===2?red:blue):n===6?(i<2?green:red):n===7?(i<3?green:red):n===9?(i>=3&&i<6?red:blue):blue)).join('');
  }
  function bamboo(n){
    if(n===1)return `<g fill="none" stroke="${green}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M28 26C22 23 21 17 25 14C29 10 35 11 36 16C37 21 33 24 30 26M35 16l8 2-8 3M26 12l-4-4m7 3l-1-5m5 6l3-5"/><circle cx="31" cy="16" r="1" fill="${green}"/><path d="M27 25C20 29 20 40 25 48C29 55 37 52 38 45C39 36 33 33 31 25M24 31Q30 26 34 34Q37 42 30 47Q24 44 25 37Z M27 32q7 4 6 11m-8-6l6 8m-8-3l6 6M25 49l4 12m7-12l3 10M29 61l-5 3m5-3l5 2m5-4l-3 3m3-3l5 1"/><path d="M23 35L13 26L10 24L14 42L24 49M19 34L15 32L18 43M24 46L18 55L22 69L30 58M21 54l4 10M31 51L34 66L40 73L37 56"/><path d="M21 30Q14 27 13 21Q13 17 17 18Q21 21 18 25M23 36Q12 38 9 34Q5 30 9 29Q13 28 15 33M36 31Q42 25 46 29Q49 32 44 34Q40 35 39 31M38 39Q46 36 49 40Q51 44 46 44Q42 44 42 40" stroke-width="1.3"/></g>`;
    if(n===8)return [0,1].map(row=>{const y=row?46:12;const a=row?y+20:y,b=row?y:y+20;return `<g fill="none" stroke="${green}" stroke-linecap="round" stroke-linejoin="round"><path d="M11 ${a}V${b}L30 ${a}L49 ${b}V${a}" stroke-width="5"/><path d="M11 ${a}V${b}L30 ${a}L49 ${b}V${a}" stroke="#e9e2d0" stroke-width="1.5"/><path d="M8 ${y+4}h6m-6 12h6M46 ${y+4}h6m-6 12h6" stroke-width="1.4"/></g>`;}).join('');
    const points={2:[[30,20],[30,60]],3:[[30,18],[17,59],[43,59]],4:[[17,20],[43,20],[17,60],[43,60]],5:[[14,17],[46,17],[30,40],[14,63],[46,63]],6:[[14,20],[30,20],[46,20],[14,60],[30,60],[46,60]],7:[[30,12],[14,38],[30,38],[46,38],[14,64],[30,64],[46,64]],9:[[14,15],[30,15],[46,15],[14,40],[30,40],[46,40],[14,65],[30,65],[46,65]]}[n];
    return points.map(([x,y],i)=>stick(x,y,n===5&&i===2||n===7&&i===0||n===9&&i>=3&&i<6?red:green,n===2?27:18)).join('');
  }
  function markup(code){
    if(code==='T1'||code==='T8'){const asset=code==='T1'?'26-bamboos-1':'33-bamboos-8';return `<svg class="tile-art" viewBox="0 0 60 80" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg"><image href="./tile-assets/${asset}.svg" width="60" height="80" preserveAspectRatio="xMidYMid meet"/></svg>`;}
    const n=Number(code[1]);let art='';
    if(code[0]==='B')art=dots(n);
    else if(code[0]==='T')art=bamboo(n);
    else if(code[0]==='W')art=text('一二三四五六七八九'[n-1],30,22,31,blue)+text('萬',30,57,36,red);
    else if(code==='J3')art=`<rect x="11" y="9" width="38" height="62" rx="2" fill="none" stroke="${blue}" stroke-width="3"/><rect x="16" y="14" width="28" height="52" rx="1" fill="none" stroke="${blue}" stroke-width="1"/>`;
    else art=text(code[0]==='F'?'東南西北'[n-1]:n===1?'中':'發',30,40,49,code[0]==='F'?blue:n===1?red:green);
    return `<svg class="tile-art" viewBox="0 0 60 80" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">${art}</svg>`;
  }
  return {markup};
})();
